import PlaygroundSupport
import SpriteKit


class GameScene: SKScene {
    
    
    override func didMove(to view: SKView) {

    }
    
    
    
    
    
    
    
    
    
}











var size = CGSize(width: UIScreen.main.nativeBounds.size.width, height: UIScreen.main.nativeBounds.size.height)
/* let deviceWidth =
let deviceHeight = UIScreen.main.bounds.height */
let skView = SKView(frame: CGRect(origin: CGPoint.zero, size: size))
let scene = GameScene(size: skView.frame.size)

skView.presentScene(scene)






PlaygroundPage.current.liveView =  skView





