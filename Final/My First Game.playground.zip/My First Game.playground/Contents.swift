import PlaygroundSupport
import SpriteKit


class GameScene: SKScene {
    
    var robot = SKSpriteNode(imageNamed: "Robot")
    
    override func didMove(to view: SKView) {
        robot.position = CGPoint(x: size.height * 0.5, y: size.width * 0.5)
        
        addChild(robot)
    }
    
    
    
    
    
    
    
    
    
}











var size = CGSize(width: UIScreen.main.nativeBounds.size.width, height: UIScreen.main.nativeBounds.size.height)
/* let deviceWidth =
let deviceHeight = UIScreen.main.bounds.height */
let skView = SKView(frame: CGRect(origin: CGPoint.zero, size: size))
let scene = GameScene(size: skView.frame.size)

skView.presentScene(scene)






PlaygroundPage.current.liveView =  skView





